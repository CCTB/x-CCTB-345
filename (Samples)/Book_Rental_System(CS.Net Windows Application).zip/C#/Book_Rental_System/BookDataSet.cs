﻿namespace Book_Rental_System {
    
    
    public partial class BookDataSet {
    }
}
