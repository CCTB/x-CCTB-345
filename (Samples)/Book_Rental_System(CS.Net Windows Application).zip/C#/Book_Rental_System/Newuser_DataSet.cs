﻿namespace Book_Rental_System {
    
    
    public partial class Newuser_DataSet {
    }
}
